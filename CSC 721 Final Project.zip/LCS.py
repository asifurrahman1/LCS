import numpy as np

def lcs_recursive(str1, str2, m , n):
  if m == 0 or n == 0:
        return ""
  if str1[m - 1] == str2[n - 1]:
        return lcs_recursive(str1, str2, m - 1, n - 1) + str1[m - 1]
  else:
        t1 = lcs_recursive(str1, str2, m, n-1)
        t2 = lcs_recursive(str1, str2, m-1, n)
        if len(t1) > len(t2):
          return t1
        else:
          return t2

#------------------------------------------------------------------------------
#------------------------------------------------------------------------------
def lcs_memoized(str1, str2, m, n, memo={}):
  key= (m,n)
  if m == 0 or n == 0: 
    return ''
  elif (m,n) in memo:
    return memo[key]
  else:
    if str1[m - 1] == str2[n - 1]:
      memo[key] = lcs_memoized(str1, str2, m - 1, n - 1, memo) + str1[m - 1]
    else:
      option1 = lcs_memoized(str1, str2, m, n-1, memo)
      option2 = lcs_memoized(str1, str2, m-1, n, memo)
      if len(option1) > len(option2):
        memo[key] =  option1
      else:
        memo[key] = option2
    return memo[key]
#------------------------------------------------------------------------------
#------------------------------------------------------------------------------
def lcs_dp_table(str1, str2):
  m = len(str1)
  n = len(str2)
  DP_table = np.zeros([m+1,n+1])
  for i in range(1,m+1):
    for j in range(1,n+1):
      if (str1[i-1] == str2[j-1]):
          DP_table[i, j] = DP_table[i-1, j-1] + 1
      else:
          DP_table[i, j] = max( DP_table[i,j-1], DP_table[i-1,j])
  return DP_table

def lcs_traceback_dp_table(table, str1, str2):
    m = table.shape[0]-1
    n = table.shape[1]-1
    i = m
    j = n
    sub_sequence_index =[]
    while i>=1 and j>=1:
        if table[i][j] ==  table[i][j-1]:
          j = j-1
        if table[i][j] ==  table[i-1][j]:
          i = i-1
        else:
          i = i-1
          j = j-1
          sub_sequence_index.append(i)
    sub_sequence_index.reverse()
    sub_seq = []
    for i in sub_sequence_index:
      sub_seq.append(str1[i])
    return sub_seq

def LCS_DP(str1,str2):
  table = lcs_dp_table(str1,str2)
  sub_sequence = lcs_traceback_dp_table(table,str1,str2)
  return sub_sequence


#------------------------------------------------------------------------------
#------------------------------------------------------------------------------
def LCS_H_S(s1, s2):
    if len(s1) > len(s2):
        s1, s2 = s2, s1
    equal = {}
    if '' == s1:
        return 0
    for i in range(0, len(s2)):
        equal[i + 1] = get_hash_index(s2[i], s1)[::-1]

    threshold = [len(s1) + 1 for _ in range(0, len(s2) + 1)]
    threshold[0] = 0
    # print("\n\ninit threshold :", threshold)
    index_prev = -1
    for i in range(0, len(s2)):
        # print("threshold :", threshold)
        for j in equal[i + 1]:
            k = binary_insert(j, threshold)  
            if j < threshold[k]:
                threshold[k] = j
                
    result = 0
    for k in range(len(s2), 0, -1):
        if len(s1) + 1 != threshold[k]:
            result = k
            break
    seq = []
    for i in range(1,result+1):
      seq.append(s1[threshold[i]])
    return seq

def get_hash_index(c, s):
    result = []
    i = 0
    while i < len(s):
        if type(s) == list:
            try:
                i = s[i:].index(c) + i + 1
            except ValueError:
                i = 0
        else:
            i = s.find(c, i) + 1
        if 0 != i:
            result.append(i - 1)
        else:
            break
    return result


def binary_insert(j, threshold, left=None, right=None):
    if (None, None) == (left, right):
        left, right = 0, len(threshold) - 1

    if left > right:
        raise ValueError('Value in left higher than right')
    elif left + 1 == right or left == right:
        return right
    else:
        mid = int((left + right) / 2)
        if j <= threshold[mid]:
            left, right = left, mid
        else:
            left, right = mid, right
        return binary_insert(j, threshold, left, right)    

